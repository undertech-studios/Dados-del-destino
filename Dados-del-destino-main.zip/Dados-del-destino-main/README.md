# Dados-del-destino
Un dado de 20 con estética neón.
